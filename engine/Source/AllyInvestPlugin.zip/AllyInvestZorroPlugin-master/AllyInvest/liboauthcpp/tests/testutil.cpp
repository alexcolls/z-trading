#include "testutil.h"

namespace OAuthTest {

int TestUtil::passed = 0;
int TestUtil::failed = 0;
std::vector<TestUtil::Details> TestUtil::failed_details;

}
